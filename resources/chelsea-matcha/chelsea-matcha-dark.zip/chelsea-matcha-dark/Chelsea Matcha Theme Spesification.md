# Color Palette

| Element        | Color                                                      | Hex       |
| -------------- | ---------------------------------------------------------- | --------- |
| background     | <div style="background-color:#1a2b1e;padding:10px;"></div> | `#1a2b1e` |
|                | <div style="background-color:#1e241f;padding:10px;"></div> | `#1e241f` |
|                | <div style="background-color:#253d2a;padding:10px;"></div> | `#253d2a` |
| selected       | <div style="background-color:#117729;padding:10px;"></div> | `#117729` |
| selected-hover | <div style="background-color:#179f36;padding:10px;"></div> | `#179f36` |
